﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CenterManagement.Infrustructure.Data.Migrations;

/// <inheritdoc />
public partial class addstudentmultigroup : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "FK_StudentGroups_Groups_GroupId",
            table: "StudentGroups");

        migrationBuilder.DropForeignKey(
            name: "FK_Students_Groups_GroupId",
            table: "Students");

        migrationBuilder.DropIndex(
            name: "IX_Students_GroupId",
            table: "Students");

        migrationBuilder.DropColumn(
            name: "GroupId",
            table: "Students");

        migrationBuilder.AddColumn<bool>(
            name: "IsActive",
            table: "StudentGroups",
            type: "bit",
            nullable: false,
            defaultValue: false);

        migrationBuilder.AddColumn<DateTime>(
            name: "LeftAt",
            table: "StudentGroups",
            type: "datetime2",
            nullable: true);

        migrationBuilder.AddForeignKey(
            name: "FK_StudentGroups_Groups_GroupId",
            table: "StudentGroups",
            column: "GroupId",
            principalTable: "Groups",
            principalColumn: "Id",
            onDelete: ReferentialAction.Cascade);
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "FK_StudentGroups_Groups_GroupId",
            table: "StudentGroups");

        migrationBuilder.DropColumn(
            name: "IsActive",
            table: "StudentGroups");

        migrationBuilder.DropColumn(
            name: "LeftAt",
            table: "StudentGroups");

        migrationBuilder.AddColumn<Guid>(
            name: "GroupId",
            table: "Students",
            type: "uniqueidentifier",
            nullable: false,
            defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

        migrationBuilder.CreateIndex(
            name: "IX_Students_GroupId",
            table: "Students",
            column: "GroupId");

        migrationBuilder.AddForeignKey(
            name: "FK_StudentGroups_Groups_GroupId",
            table: "StudentGroups",
            column: "GroupId",
            principalTable: "Groups",
            principalColumn: "Id");

        migrationBuilder.AddForeignKey(
            name: "FK_Students_Groups_GroupId",
            table: "Students",
            column: "GroupId",
            principalTable: "Groups",
            principalColumn: "Id",
            onDelete: ReferentialAction.Cascade);
    }
}
