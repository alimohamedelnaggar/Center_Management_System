﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CenterManagement.Infrustructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class asd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents");

            migrationBuilder.DropForeignKey(
                name: "FK_StudentExamComponents_Students_StudentId",
                table: "StudentExamComponents");

            migrationBuilder.DropPrimaryKey(
                name: "PK_StudentExamComponents",
                table: "StudentExamComponents");

            migrationBuilder.AlterColumn<Guid>(
                name: "StudentId",
                table: "StudentExamComponents",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier");

            migrationBuilder.AddColumn<Guid>(
                name: "Id",
                table: "StudentExamComponents",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddPrimaryKey(
                name: "PK_StudentExamComponents",
                table: "StudentExamComponents",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_StudentExamComponents_StudentId",
                table: "StudentExamComponents",
                column: "StudentId");

            migrationBuilder.AddForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents",
                column: "ExamComponentId",
                principalTable: "ExamComponents",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_StudentExamComponents_Students_StudentId",
                table: "StudentExamComponents",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents");

            migrationBuilder.DropForeignKey(
                name: "FK_StudentExamComponents_Students_StudentId",
                table: "StudentExamComponents");

            migrationBuilder.DropPrimaryKey(
                name: "PK_StudentExamComponents",
                table: "StudentExamComponents");

            migrationBuilder.DropIndex(
                name: "IX_StudentExamComponents_StudentId",
                table: "StudentExamComponents");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "StudentExamComponents");

            migrationBuilder.AlterColumn<Guid>(
                name: "StudentId",
                table: "StudentExamComponents",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"),
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_StudentExamComponents",
                table: "StudentExamComponents",
                columns: new[] { "StudentId", "ExamComponentId" });

            migrationBuilder.AddForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents",
                column: "ExamComponentId",
                principalTable: "ExamComponents",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StudentExamComponents_Students_StudentId",
                table: "StudentExamComponents",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "Id");
        }
    }
}
