﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CenterManagement.Infrustructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class SessionsPerMonth : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BilledSessions",
                table: "StudentAmounts",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SessionsPerMonth",
                table: "Groups",
                type: "int",
                nullable: false,
                defaultValue: 8);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BilledSessions",
                table: "StudentAmounts");

            migrationBuilder.DropColumn(
                name: "SessionsPerMonth",
                table: "Groups");
        }
    }
}
