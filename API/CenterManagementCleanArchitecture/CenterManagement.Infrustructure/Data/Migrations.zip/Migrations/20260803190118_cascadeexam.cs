﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CenterManagement.Infrustructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class cascadeexam : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ExamComponents_Exams_ExamId",
                table: "ExamComponents");

            migrationBuilder.DropForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents");

            migrationBuilder.AddForeignKey(
                name: "FK_ExamComponents_Exams_ExamId",
                table: "ExamComponents",
                column: "ExamId",
                principalTable: "Exams",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents",
                column: "ExamComponentId",
                principalTable: "ExamComponents",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ExamComponents_Exams_ExamId",
                table: "ExamComponents");

            migrationBuilder.DropForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents");

            migrationBuilder.AddForeignKey(
                name: "FK_ExamComponents_Exams_ExamId",
                table: "ExamComponents",
                column: "ExamId",
                principalTable: "Exams",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_StudentExamComponents_ExamComponents_ExamComponentId",
                table: "StudentExamComponents",
                column: "ExamComponentId",
                principalTable: "ExamComponents",
                principalColumn: "Id");
        }
    }
}
